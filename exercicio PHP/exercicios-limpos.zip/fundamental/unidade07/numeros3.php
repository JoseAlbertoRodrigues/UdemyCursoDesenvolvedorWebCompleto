<?php
    $gasolina = 4.55;
?>

<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Curso PHP FUNDAMENTAL</title>
    </head>

    <body>
        
        
        <?php
            // arredondar para media


            // arredondar para cima


            // arredondar para baixo


            
        ?>
        
        
    </body>
</html>