<?php 
    $_nome = "Curso PHP Fundamental";
?>

<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Curso PHP FUNDAMENTAL</title>
    </head>

    <body>
        
        <?php 
            // strlen - Retorna primeira ocorrencia
            
            
            // stripos  - Retorna primeira ocorrência 
            

            // strripos - Retorna última ocorrência
            
            
            // strtolower - converte para letras min.
            

            // strtoupper - converte para letras min.
            

            // SUBSTR_COUNT - Conta quantas ocorreram
            // de um texto ou string
            // Faz diferença Maiusculas e minusculas
            
        ?>
        
        
    </body>
</html>