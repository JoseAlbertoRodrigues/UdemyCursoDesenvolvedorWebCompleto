<?php 
    $salario = 800;
    $meses   = 3;
?>

<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Curso PHP FUNDAMENTAL</title>
    </head>

    <body>
        <?php 
            // Multiplicacao e Divisao

            // Exponencial
            echo "Raiz quadrada: " . pow(6,3) . "</br>";

            // Raiz Quadrada

            // Randômico Generica
            echo "Randomico: " . rand(1,5) . "</br>";

            // Randômico entre um intervalo
            echo "Randomico no intervalo " . rand() . "</br>";
            
            // Valor absoluto
            
        ?>
    </body>
</html>